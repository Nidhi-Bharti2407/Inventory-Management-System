@extends('layouts.app')
@section('content')
<span style="margin-top:120px;"></span>
@include('layouts.blank')


@endsection