@extends('layouts.app')
@section('content')
<div class="content-wrapper">
<div class="box">
            <div class="box-header">
              <h3 class="box-title">Admin profile</h3>
            </div>
            
            <div class="box-body">
              <table id="" class="table table-bordered vertical-align">
                <thead>
                <tr>
                 
                  <th>Name</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Phonenumber</th>
                  <th>Gender</th>

                  <th>Role</th>
                  
                </tr>
                </thead>
                <tbody>
                <tr>
                 
                  <td >Gunaraj Khatri</td>
                  <td>khatriroshan54@gmail.com
                  </td>
                  <td>Itahari</td>
                  <td>9808992161</td>
                  <td>Male</td>
                  <td>Founder and admin</td>
                  
                

                  
                </tr>
                
                
                
                
                 
                </tbody>
                <tfoot>
               
                </tfoot>
              </table>
            </div>
            
          </div>
          </div>


@endsection